<?php
/**
 * Plugin Name: PeepSo Recommendation Engine
 * Description: A plugin to recommend posts to users based on their activity and preferences.
 * Version: 1.5
 * Author: Dakota
 * Text Domain: peepso-recommendation-engine
 */
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Create database tables on plugin activation
function member_preferences_create_tables() {
    global $wpdb;

    // Dynamically resolve the table prefix (e.g., 'wpmg_' or 'wp_')
    $table_name = $wpdb->prefix . 'member_preferences'; // Resolves to wpmg_member_preferences if prefix is 'wpmg_'
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        category varchar(50) NOT NULL,
        value int(11) NOT NULL,
        timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY user_category (user_id, category)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'member_preferences_create_tables');

// Enqueue scripts and styles
add_action('wp_enqueue_scripts', 'enqueue_member_preferences_assets');
function enqueue_member_preferences_assets() {
    // Check if the page uses the template or shortcode
    if (is_page_template('page-templates/page-member-preferences.php') || has_shortcode(get_the_content(), 'member_preferences')) {
        // Explicitly enqueue jQuery
        wp_enqueue_script('jquery');

        // Enqueue CSS
        wp_enqueue_style('member-preferences-style', plugins_url('css/member-preferences.css', __FILE__));

        // Enqueue JavaScript with jQuery dependency
        wp_enqueue_script(
            'member-preferences-script',
            plugins_url('js/member-preferences.js', __FILE__),
            ['jquery'],
            false,
            true
        );

        // Default range and step values
        $default_min = 0;
        $default_max = 100;
        $default_step = 1;

        // Define categories with their assigned colors
        $categories = [
            'technology' => ['color' => '#0073aa'],
            'lifestyle' => ['color' => '#ff9800'],
            'sports' => ['color' => '#4caf50'],
            'entertainment' => ['color' => '#e91e63'],
            'education' => ['color' => '#9c27b0'],
            'health' => ['color' => '#8bc34a'],
            'travel' => ['color' => '#03a9f4'],
            'comedy' => ['color' => '#f44336'],
            'pets' => ['color' => '#ffc107'],
            'global_news' => ['color' => '#673ab7'],
        ];

        // Pass PHP variables to JavaScript
        wp_localize_script('member-preferences-script', 'memberPreferencesData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'userId'  => get_current_user_id(),
            'categories' => $categories,
            'nonce'   => wp_create_nonce('save_preferences_nonce'),
        ]);
    }
}

// AJAX handler to save preferences
add_action('wp_ajax_save_preferences', 'save_preferences');
function save_preferences() {
    // Log when the request is received
    error_log('AJAX Request Received');

    // Verify nonce for security
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'save_preferences_nonce')) {
        error_log('Nonce Validation Failed'); // Log nonce validation failure
        wp_send_json_error(['message' => __('Invalid or expired token. Please refresh the page.', 'peepso-recommendation-engine')]);
    }

    // Validate user ID
    $user_id = absint($_POST['user_id']);
    if (!$user_id) {
        error_log('Invalid User ID'); // Log invalid user ID
        wp_send_json_error(['message' => __('Invalid user ID.', 'peepso-recommendation-engine')]);
    }

    

    // List of categories
    $categories = ['technology', 'lifestyle', 'sports', 'entertainment', 'education', 'health', 'travel', 'comedy', 'pets', 'global_news'];

    // Save preferences to the custom table
    global $wpdb;
    $table_name = $wpdb->prefix . 'member_preferences'; // Resolves to wpmg_member_preferences if prefix is 'wpmg_'
    foreach ($categories as $category) {
        if (isset($_POST[$category])) {
            $value = absint($_POST[$category]);
            $wpdb->replace(
                $table_name,
                [
                    'user_id' => $user_id,
                    'category' => sanitize_text_field($category),
                    'value' => $value,
                ]
            );
        }
    }

    // Fetch the latest saved preferences
    $saved_preferences = [];
    foreach ($categories as $category) {
        $row = $wpdb->get_row($wpdb->prepare("SELECT value FROM $table_name WHERE user_id = %d AND category = %s", $user_id, $category));
        $saved_preferences[$category] = $row ? absint($row->value) : 0;
    }

    // Log the saved preferences
    error_log('Saved Preferences: ' . print_r($saved_preferences, true));

    // Return success message and saved preferences
    wp_send_json_success([
        'message' => __('Preferences saved successfully!', 'peepso-recommendation-engine'),
        'preferences' => $saved_preferences,
    ]);
}

// Shortcode to display the preferences page
add_shortcode('member_preferences', 'display_member_preferences');
function display_member_preferences() {
    ob_start();
    include plugin_dir_path(__FILE__) . 'page-templates/page-member-preferences.php';
    return ob_get_clean();
}

// Export preferences as CSV
add_action('admin_post_export_member_preferences', 'export_member_preferences');
function export_member_preferences() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'member_preferences'; // Resolves to wpmg_member_preferences if prefix is 'wpmg_'
    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY user_id, category", ARRAY_A);

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="member-preferences-export.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'User ID', 'Category', 'Value', 'Timestamp']);

    foreach ($results as $row) {
        fputcsv($output, array_map('esc_html', $row));
    }

    fclose($output);
    exit;
}

// Add a settings page for exporting preferences
function member_preferences_add_settings_page() {
    add_options_page(
        __('Member Preferences Settings', 'peepso-recommendation-engine'),
        __('Member Preferences', 'peepso-recommendation-engine'),
        'manage_options',
        'member-preferences-settings',
        'member_preferences_render_settings_page'
    );
}
add_action('admin_menu', 'member_preferences_add_settings_page');

function member_preferences_render_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Member Preferences Settings', 'peepso-recommendation-engine'); ?></h1>
        <p>
            <a href="<?php echo esc_url(admin_url('admin-post.php?action=export_member_preferences')); ?>" 
               onclick="return confirm('<?php _e('Are you sure you want to export member preferences?', 'peepso-recommendation-engine'); ?>');">
                <?php _e('Export Member Preferences', 'peepso-recommendation-engine'); ?>
            </a>
        </p>
    </div>
    <?php
}