<?php
/*
Template Name: Member Preferences
*/
get_header();

// Check if the user is logged in
if (!is_user_logged_in()) {
    echo '<p>' . __('Please log in to access this page.', 'peepso-recommendation-engine') . '</p>';
    return;
}

$user_id = get_current_user_id();

// Fetch preferences from the custom table
global $wpdb;
$table_name = $wpdb->prefix . 'member_preferences'; // Automatically resolves to wpmg_member_preferences
$preferences = $wpdb->get_results($wpdb->prepare("
    SELECT category, value FROM $table_name WHERE user_id = %d
", $user_id), ARRAY_A);

// Convert preferences into an associative array
$saved_preferences = [];
foreach ($preferences as $preference) {
    $saved_preferences[sanitize_title($preference['category'])] = absint($preference['value']);
}

// Define categories with their assigned colors
$categories = [
    'technology' => ['color' => '#0073aa'],
    'lifestyle' => ['color' => '#ff9800'],
    'sports' => ['color' => '#4caf50'],
    'entertainment' => ['color' => '#e91e63'],
    'education' => ['color' => '#9c27b0'],
    'health' => ['color' => '#8bc34a'],
    'travel' => ['color' => '#03a9f4'],
    'comedy' => ['color' => '#f44336'],
    'pets' => ['color' => '#ffc107'],
    'global_news' => ['color' => '#673ab7'],
];

// Default range and step values for all sliders
$default_min = 0;
$default_max = 100;
$default_step = 1;
?>
<div class="member-preferences">
    <h1><?php _e('Set Your Preferences', 'peepso-recommendation-engine'); ?></h1>
    <!-- Placeholder for success/error messages -->
    <div id="form-messages" style="display: none;"></div>
    <form id="preferences-form">
        <?php foreach ($categories as $category => $options): ?>
            <div class="slider-container">
                <!-- Label with Tooltip -->
                <label for="<?php echo esc_attr(sanitize_title($category)); ?>" 
                       data-tooltip="<?php echo esc_attr(sprintf(__('Adjust your interest in %s', 'peepso-recommendation-engine'), str_replace('_', ' ', $category))); ?>"
                       aria-label="<?php echo esc_attr(sprintf(__('Adjust your interest in %s', 'peepso-recommendation-engine'), str_replace('_', ' ', $category))); ?>">
                    <?php echo esc_html(str_replace('_', ' ', $category)); ?>
                </label>
                <!-- Slider Input -->
                <input type="range" 
                       id="<?php echo esc_attr(sanitize_title($category)); ?>" 
                       name="<?php echo esc_attr(sanitize_title($category)); ?>" 
                       min="<?php echo esc_attr($default_min); ?>" 
                       max="<?php echo esc_attr($default_max); ?>" 
                       step="<?php echo esc_attr($default_step); ?>" 
                       value="<?php echo esc_attr($saved_preferences[sanitize_title($category)] ?? $default_min); ?>"
                       style="--slider-color: <?php echo esc_attr($options['color']); ?>;">
                <!-- Slider Value Display -->
                <span class="slider-value"><?php echo esc_html($saved_preferences[sanitize_title($category)] ?? $default_min); ?></span>
            </div>
        <?php endforeach; ?>
        <button type="submit"><?php _e('Save Preferences', 'peepso-recommendation-engine'); ?></button>
    </form>
</div>
<?php
get_footer();