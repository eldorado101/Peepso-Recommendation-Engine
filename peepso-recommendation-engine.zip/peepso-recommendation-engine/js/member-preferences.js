document.addEventListener('DOMContentLoaded', function() { // Changed arrow function to function keyword
    console.log('JavaScript is working!');
    console.log('Member Preferences Data:', memberPreferencesData);

    // Initialize sliders
    var sliders = document.querySelectorAll('.slider-container input[type="range"]'); // Changed const to var
    if (!sliders.length) {
        console.error('No sliders found!');
        return;
    }

    var categoryData = memberPreferencesData.categories || {}; // Changed const to var
    sliders.forEach(function(slider) { // Changed arrow function to function keyword
        var category = slider.getAttribute('name'); // Changed const to var
        var color = (categoryData[category] && categoryData[category].color) || '#0073aa'; // Removed optional chaining
        slider.style.setProperty('--slider-color', color);
        
        var output = slider.nextElementSibling; // Changed const to var
        var initialValue = parseFloat(slider.value); // Changed const to var
        output.textContent = initialValue;
        slider.style.setProperty('--value', (initialValue / slider.max) * 100 + '%');

        slider.addEventListener('input', function() {
            var value = parseFloat(this.value); // Changed const to var
            output.textContent = value;
            this.style.setProperty('--value', (value / this.max) * 100 + '%');
        });
    });

    // Handle form submission
    var form = document.getElementById('preferences-form'); // Changed const to var
    if (form) {
        form.addEventListener('submit', function(e) { // Changed arrow function to function keyword
            e.preventDefault();
            
            var formData = new FormData(form); // Changed const to var
            formData.append('nonce', memberPreferencesData.nonce);
            formData.append('action', 'save_preferences');
            formData.append('user_id', memberPreferencesData.userId);

            fetch(memberPreferencesData.ajaxUrl, {
                method: 'POST',
                body: new URLSearchParams(formData),
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            })
            .then(function(response) { // Changed arrow function to function keyword
                if (!response.ok) throw new Error('Network error');
                return response.json();
            })
            .then(function(data) { // Changed arrow function to function keyword
                console.log('Server Response:', data);

                // Show success message
                alert((data && data.data && data.data.message) || 'Preferences saved successfully!');

                // Get preferences from nested data structure
                var savedPreferences = (data && data.data && data.data.preferences) || {}; // Changed const to var
                console.log('Saved Preferences:', savedPreferences);

                // Update sliders
                sliders.forEach(function(slider) { // Changed arrow function to function keyword
                    var category = slider.getAttribute('name'); // Changed const to var
                    var output = slider.nextElementSibling; // Changed const to var
                    
                    // Get value with fallback to 0
                    var savedValue = (savedPreferences[category] !== undefined) ? savedPreferences[category] : 0; // Replaced ?? with ternary
                    var clampedValue = Math.min(Math.max(savedValue, slider.min), slider.max);

                    // Update UI elements
                    slider.value = clampedValue;
                    output.textContent = clampedValue;
                    slider.style.setProperty('--value', (clampedValue / slider.max) * 100 + '%');
                });

            })
            .catch(function(error) { // Changed arrow function to function keyword
                console.error('Save Error:', error);
                alert('Error saving preferences. Please try again.');
            });
        });
    }
});